﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double valor1;
        double valor2;
        double valor3;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero2(object sender, EventArgs e)
        {
         
        }

        private void txtResultado(object sender, EventArgs e)
        {

        }

        private void Sair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Limpar_Click(object sender, EventArgs e)
        {
            num1.Text=String.Empty;
            num2.Text = String.Empty;
            num3.Text = String.Empty;
        }

        private void bSoma_Click(object sender, EventArgs e)
        {
         

           Double Resultado = valor1+valor2 ;


        
            num3.Text = Resultado.ToString();
        }

        private void bSubtrair_Click(object sender, EventArgs e)
        {

            Double Resultado = valor1 - valor2;



            num3.Text = Resultado.ToString();
        }

        private void bMult_Click(object sender, EventArgs e)
        {
           

            Double Resultado = valor1 * valor2;



            num3.Text = Resultado.ToString();
        }

        private void bDiv_Click(object sender, EventArgs e)
        {
            Double valor1 = double.Parse(num1.Text);
            Double valor2 = double.Parse(num2.Text);

            Double Resultado = valor1 / valor2;



            num3.Text = Resultado.ToString();
        }

        private void num1_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(num1.Text, out valor1))
                MessageBox.Show("Numero 1 inválido");
            num1.Focus();

        }

        private void num2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(num2.Text, out valor2))
                MessageBox.Show("Numero 2 inválido");
            num2.Focus();
        }
    }
}
