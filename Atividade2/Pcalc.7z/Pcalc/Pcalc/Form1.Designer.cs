﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.num1 = new System.Windows.Forms.TextBox();
            this.num2 = new System.Windows.Forms.TextBox();
            this.num3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Limpar = new System.Windows.Forms.Button();
            this.Sair = new System.Windows.Forms.Button();
            this.bSoma = new System.Windows.Forms.Button();
            this.bSubtrair = new System.Windows.Forms.Button();
            this.bMult = new System.Windows.Forms.Button();
            this.bDiv = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Número 2";
            // 
            // num1
            // 
            this.num1.Location = new System.Drawing.Point(213, 66);
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(195, 26);
            this.num1.TabIndex = 2;
            this.num1.Validated += new System.EventHandler(this.num1_Validated);
            // 
            // num2
            // 
            this.num2.Location = new System.Drawing.Point(213, 129);
            this.num2.Name = "num2";
            this.num2.Size = new System.Drawing.Size(195, 26);
            this.num2.TabIndex = 3;
            this.num2.TextChanged += new System.EventHandler(this.txtNumero2);
            this.num2.Validated += new System.EventHandler(this.num2_Validated);
            // 
            // num3
            // 
            this.num3.Enabled = false;
            this.num3.Location = new System.Drawing.Point(213, 225);
            this.num3.Name = "num3";
            this.num3.Size = new System.Drawing.Size(195, 26);
            this.num3.TabIndex = 4;
            this.num3.TextChanged += new System.EventHandler(this.txtResultado);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Resultado";
            this.label3.TextChanged += new System.EventHandler(this.txtResultado);
            // 
            // Limpar
            // 
            this.Limpar.Location = new System.Drawing.Point(533, 66);
            this.Limpar.Name = "Limpar";
            this.Limpar.Size = new System.Drawing.Size(191, 85);
            this.Limpar.TabIndex = 6;
            this.Limpar.Text = "Limpar";
            this.Limpar.UseVisualStyleBackColor = true;
            this.Limpar.Click += new System.EventHandler(this.Limpar_Click);
            // 
            // Sair
            // 
            this.Sair.Location = new System.Drawing.Point(533, 166);
            this.Sair.Name = "Sair";
            this.Sair.Size = new System.Drawing.Size(191, 85);
            this.Sair.TabIndex = 7;
            this.Sair.Text = "Sair";
            this.Sair.UseVisualStyleBackColor = true;
            this.Sair.Click += new System.EventHandler(this.Sair_Click);
            // 
            // bSoma
            // 
            this.bSoma.Location = new System.Drawing.Point(29, 313);
            this.bSoma.Name = "bSoma";
            this.bSoma.Size = new System.Drawing.Size(152, 79);
            this.bSoma.TabIndex = 8;
            this.bSoma.Text = "+";
            this.bSoma.UseVisualStyleBackColor = true;
            this.bSoma.Click += new System.EventHandler(this.bSoma_Click);
            // 
            // bSubtrair
            // 
            this.bSubtrair.Location = new System.Drawing.Point(201, 313);
            this.bSubtrair.Name = "bSubtrair";
            this.bSubtrair.Size = new System.Drawing.Size(168, 77);
            this.bSubtrair.TabIndex = 9;
            this.bSubtrair.Text = "-";
            this.bSubtrair.UseVisualStyleBackColor = true;
            this.bSubtrair.Click += new System.EventHandler(this.bSubtrair_Click);
            // 
            // bMult
            // 
            this.bMult.Location = new System.Drawing.Point(388, 313);
            this.bMult.Name = "bMult";
            this.bMult.Size = new System.Drawing.Size(162, 77);
            this.bMult.TabIndex = 10;
            this.bMult.Text = "*";
            this.bMult.UseVisualStyleBackColor = true;
            this.bMult.Click += new System.EventHandler(this.bMult_Click);
            // 
            // bDiv
            // 
            this.bDiv.Location = new System.Drawing.Point(569, 313);
            this.bDiv.Name = "bDiv";
            this.bDiv.Size = new System.Drawing.Size(155, 77);
            this.bDiv.TabIndex = 11;
            this.bDiv.Text = "/";
            this.bDiv.UseVisualStyleBackColor = true;
            this.bDiv.Click += new System.EventHandler(this.bDiv_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bDiv);
            this.Controls.Add(this.bMult);
            this.Controls.Add(this.bSubtrair);
            this.Controls.Add(this.bSoma);
            this.Controls.Add(this.Sair);
            this.Controls.Add(this.Limpar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.num3);
            this.Controls.Add(this.num2);
            this.Controls.Add(this.num1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox num1;
        private System.Windows.Forms.TextBox num2;
        private System.Windows.Forms.TextBox num3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Limpar;
        private System.Windows.Forms.Button Sair;
        private System.Windows.Forms.Button bSoma;
        private System.Windows.Forms.Button bSubtrair;
        private System.Windows.Forms.Button bMult;
        private System.Windows.Forms.Button bDiv;
    }
}

